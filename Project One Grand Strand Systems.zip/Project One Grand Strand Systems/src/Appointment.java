import java.util.Date;


/*
 * Matt Zindler CS-320
 */

public class Appointment {
	
	private String appointmentID;  // setting up variables
	private Date appointmentDate = new Date();
	private String appointmentDescription;
	Date currentDate = new Date(System.currentTimeMillis());
	
	public Appointment (String ID, Date date, String description) {  // method to add an appointment
		
		if (ID == null || ID.length() > 10) {  // checks for invalid or null inputs
			throw new IllegalArgumentException("Invalid ID.");
		}
		if (date == null || date.compareTo(currentDate) < 0) {
			throw new IllegalArgumentException("Invalid date.");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description length.");
		}
		
		appointmentID = ID;  // sets private variables to user inputs
		appointmentDate = date;
		appointmentDescription = description;	
	}
	
	public String getID() {  // getter method for ID
		return appointmentID;
	}
	public Date getDate() {  // getter method for date
		return appointmentDate;
	}
	public String getDescription() {  // getter method for description
		return appointmentDescription;
	}
	
	public void setAppointmentID(String ID) {  // setter method for ID
		appointmentID = ID;
	}
	public void setAppointmentDate(Date date) {  // setter method for date
		appointmentDate = date;
	}
	public void setAppointmentDescription(String description) {  // setter method for description
		appointmentDescription = description;
	}
}
