package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {
	
	@Test
	void testTask() {  // checks class instantiation
		Task testTask = new Task("1", "task name", "details for appointment");
		assertTrue(testTask.getID().equals("1"));
		assertTrue(testTask.getName().equals("task name"));
		assertTrue(testTask.getDescription().equals("details for appointment"));
	}
	
	@Test
	void testTaskIDTooLong() {  // checks if the ID is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678910", "task name", "test details");
		});	
	}
	@Test
	void testTaskIDNull() {  // tests for null inputs
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "task name", "test details");
		});
	}
	
	
	@Test
	void testTaskNameTooLong() {  // checks if the date is incorrect
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567890", "task name12345678910111213141516", "test details");
		});	
	}
	@Test
	void testTaskNameNull() {  // tests for null inputs
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567890", null, "test details");
		});
	}
	
	
	@Test
	void testTaskDescriptionTooLong() {  // checks if the description is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567890", "task name", "test details11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111");
		});	
	}
	@Test
	void testTaskDescriptionNull() {  // tests for null inputs
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567890", "task name", null);
		});
	}
}