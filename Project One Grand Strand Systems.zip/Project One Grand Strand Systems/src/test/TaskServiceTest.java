package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

	@Test
	void testTask() {  // checks class instantiation
		Task testTask = new Task("1", "task name", "details for appointment");
		assertTrue(testTask.getID().equals("1"));
		assertTrue(testTask.getName().equals("task name"));
		assertTrue(testTask.getDescription().equals("details for appointment"));
	}
	
	@Test
	void testCheckUniqueID() {  // checks class instantiation
		Task testTask = new Task("1", "task name", "details for appointment");
		Task testTask2 = new Task("2", "task name 2", "new details for appointment");
		assertTrue(testTask.getID().equals("1"));
		assertTrue(testTask.getName().equals("task name"));
		assertTrue(testTask.getDescription().equals("details for appointment"));
		assertTrue(testTask2.getID().equals("2"));
		assertTrue(testTask2.getName().equals("task name 2"));
		assertTrue(testTask2.getDescription().equals("new details for appointment"));
	}
	
	@Test
	void testUpdateTasks() {  // checks to update tasks
		Task testTask = new Task("1", "task name", "details for appointment");
		assertTrue(testTask.getID().equals("1"));
		assertTrue(testTask.getName().equals("task name"));
		assertTrue(testTask.getDescription().equals("details for appointment"));
		testTask.setTaskDescription("this is the new description");
		testTask.setTaskName("this is the new name");
		assertTrue(testTask.getID().equals("1"));
		assertTrue(testTask.getName().equals("this is the new name"));
		assertTrue(testTask.getDescription().equals("this is the new description"));
	}

}
