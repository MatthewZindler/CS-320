package test;

import java.util.*;

public class ContactService {
	
	String newContactID;  // creates variables for the class
	String newContactFirstName;
	String newContactLastName;
	String newContactPhoneNumber;
	String newContactAddress;
	String newContact;
	
	Vector <String> contacts = new Vector <String>(100);  // creates vector to store contacts
	
	
	public ContactService(String ID, String firstName, String lastName, String phoneNumber, String address) {	
		for (int i = 0; i < contacts.size(); i++) {
			if (ID == null || ID.length() > 10 || ID == contacts.get(i)) {  // error messages if input fields are null 
				throw new IllegalArgumentException("Invalid ID.");          // or too long or the ID is not unique
			}
		}
		if (firstName == null || firstName.length() > 10) {  // error messages if input fields are null or too long
			throw new IllegalArgumentException("Invalid first name.");
		}
		if (lastName == null || lastName.length() > 10) {  // error messages if input fields are null or too long
			throw new IllegalArgumentException("Invalid last name.");
		}
		if (phoneNumber == null || phoneNumber.length() > 10) {  // error messages if input fields are null or too long
			throw new IllegalArgumentException("Invalid phone number.");
		}
		if (address == null || address.length() > 30) {  // error messages if input fields are null or too long
			throw new IllegalArgumentException("Invalid address.");
		}
		
		newContactID = ID;
		newContactFirstName = firstName;  // adds new contact information
		newContactLastName = lastName;
		newContactPhoneNumber = phoneNumber;
		newContactAddress = address;
		
		newContact = "ID: " + newContactID + "\n" +   // creates a formatted string with contact info
					 "Contact  name: " + newContactFirstName + " " + newContactLastName + "\n" +
					 "Contact Phone number: " + newContactPhoneNumber + "\n" +
					 "Contact address: " + newContactAddress;
		
		contacts.add(newContact);  // adds the contact to the vector
	}
	
	public void removeContact(String ID) {
		for (int i = 0; i < contacts.size(); i++) {
			if (ID == contacts.get(i)) {
				contacts.remove(i);  // removes contact based on ID
			}
			
			else {
			System.out.println ("ID is not in contact list."); // error message if invalid ID
			}
		}
	}
	
	public void updateContact (String ID, String firstName, String lastName, String phoneNumber, String address) {
		for (int i = 0; i < contacts.size(); i++) {
			if (ID == contacts.get(i)) {
				contacts.remove(i); //removes previous contact information based on ID
				
				newContactFirstName = firstName;  // adds new contact information
				newContactLastName = lastName;
				newContactPhoneNumber = phoneNumber;
				newContactAddress = address;
				
				newContact = "ID: " + newContactID + "\n" +   // creates a formatted string with contact info
							 "Contact  name: " + newContactFirstName + " " + newContactLastName + "\n" +
							 "Contact Phone number: " + newContactPhoneNumber + "\n" +
							 "Contact address: " + newContactAddress;
				
				contacts.add(newContact);  // adds the contact to the vector
			}
			
			else {
			System.out.println ("ID is not in contact list.");  // error message if invalid ID
			}
		}
	}
	
	public String getIDService() {
		return newContactID;
	}
	
	public String getFirstNameService() {
		return newContactFirstName;
	}
	
	public String getLastNameService() {
		return newContactLastName;
	}
	
	public String getPhoneNumberService() {
		return newContactPhoneNumber;
	}
	
	public String getAddressService() {
		return newContactAddress;
	}
	
	
	public void setFirstNameService(String fName) {
		newContactFirstName = fName;
	}
	
	public void setLastNameService(String lName) {
		newContactLastName = lName;
	}
	
	public void setPhoneNumberService(String number) {
		newContactPhoneNumber = number;
	}
	
	public void setAddressService(String address) {
		newContactAddress = address;
	}
}
