package test;

import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {
	Date newDate = new Date (2021, 12, 27);
	
	@Test
	void testAppointmentService() {  // checks class instantiation	
		AppointmentService testAppointmentService = new AppointmentService("1", newDate, "details for appointment");
		assertTrue(testAppointmentService.getID().equals("1"));
		assertTrue(testAppointmentService.getDate().equals(newDate));
		assertTrue(testAppointmentService.getDescription().equals("details for appointment"));
	}
	
	@Test
	void checkUniqueID() {  // checks for adding multiple unique appointment IDs
		AppointmentService testAppointmentService = new AppointmentService("1", newDate, "details for appointment");
		assertTrue(testAppointmentService.getID().equals("1"));
		assertTrue(testAppointmentService.getDate().equals(newDate));
		assertTrue(testAppointmentService.getDescription().equals("details for appointment"));
		
		AppointmentService testAppointmentService2 = new AppointmentService("2", newDate, "details for appointment");
		assertTrue(testAppointmentService2.getID().equals("2"));
		assertTrue(testAppointmentService2.getDate().equals(newDate));
		assertTrue(testAppointmentService2.getDescription().equals("details for appointment"));
	}
	
}