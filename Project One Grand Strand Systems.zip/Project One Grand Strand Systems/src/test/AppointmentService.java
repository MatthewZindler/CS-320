package test;
import java.util.*;

/*
 * Matt Zindler CS-320
 */

public class AppointmentService {
	
	Vector <String> appointments = new Vector <String>(100);  // creates vector to store appointments
	
	private String appointmentID;  // setting up variables
	private Date appointmentDate = new Date();
	private String appointmentDescription;
	Date currentDate = new Date(System.currentTimeMillis());
	
	public AppointmentService (String ID, Date date, String description) {  // method to add an appointment
		for (int i = 0; i < appointments.size(); i++) {
			if (ID == null || ID.length() > 10 || ID == appointments.get(i)) {  // error messages if input fields are null 
				throw new IllegalArgumentException("Invalid ID.");          // or too long or the ID is not unique
			}
		}
		
		if (ID == null || ID.length() > 10) {  // checks for invalid or null inputs
			throw new IllegalArgumentException("Invalid ID.");
		}
		if (date == null || date.compareTo(currentDate) < 0) {
			throw new IllegalArgumentException("Invalid date.");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description length.");
		}
		
		appointmentID = ID;  // sets private variables to user inputs
		appointmentDate = date;
		appointmentDescription = description;	
	}
	
	public String getID() {  // getter method for ID
		return appointmentID;
	}
	public Date getDate() {  // getter method for date
		return appointmentDate;
	}
	public String getDescription() {  // getter method for description
		return appointmentDescription;
	}
	
	public void setAppointmentID(String ID) {  // setter method for ID
		appointmentID = ID;
	}
	public void setAppointmentDate(Date date) {  // setter method for date
		appointmentDate = date;
	}
	public void setAppointmentDescription(String description) {  // setter method for description
		appointmentDescription = description;
	}

	
	public void removeAppointment(String ID) {  // method to remove appointment based on ID
		for (int i = 0; i < appointments.size(); i++) {
			if (ID == appointments.get(i)) {
				appointments.remove(i);  // removes contact based on ID
			}
			
			else {
				System.out.println ("ID is not in contact list."); // error message if invalid ID
			}
		}
	}

}
