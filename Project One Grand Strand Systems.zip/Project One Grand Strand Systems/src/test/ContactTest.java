package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	void testContact() {  // checks class instantiation
		Contact testContact = new Contact("1", "matt", "zindler", "1234567890", "123 abc street");
		assertTrue(testContact.getID().equals("1"));
		assertTrue(testContact.getFirstName().equals("matt"));
		assertTrue(testContact.getLastName().equals("zindler"));
		assertTrue(testContact.getPhoneNumber().equals("1234567890"));
		assertTrue(testContact.getAddress().equals("123 abc street"));
		
	}
	
	@Test
	void testContactIDTooLong() {  // checks if the ID is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "matt", "zindler", "1234567890", "123 abc street");
		});	
	}
	@Test
	void testContactIDNull() {  // tests for null inputs
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "matt", "zindler", "1234567890", "123 abc street");
		});
	}
	
	
	@Test
	void testContactFirstNameTooLong() {  // checks if the first name is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "matt5678910", "zindler", "1234567890", "123 abc street");
		});	
	}
	@Test
	void testContactFirstNameNull() {  // tests for null inputs
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", null, "zindler", "1234567890", "123 abc street");
		});
	}
	
	
	@Test
	void testContactLastNameTooLong() {  // checks if the last name is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "matt", "zindler8910", "1234567890", "123 abc street");
		});	
	}
	@Test
	void testContactLastNameNull() {  // tests for null inputs
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "matt", null, "1234567890", "123 abc street");
		});
	}
	
	
	@Test
	void testContactPhoneNumberTooLong() {  // checks if the phone number is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "matt", "zindler", "12345678910", "123 abc street");
		});	
	}
	@Test
	void testContactPhoneNumberNull() {  // tests for null inputs
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "matt", "zindler", null, "123 abc street");
		});
	}
	
	
	@Test
	void testContactAddressTooLong() {  // checks if the address is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "matt", "zindler", "1234567890", "123 abc street56789212345678930");
		});	
	}
	@Test
	void testContactAddressNull() {  // tests for null inputs
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "matt", "zindler", "1234567890", null);
		});
	}
}