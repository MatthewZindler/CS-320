package test;
import java.util.*;

public class Contact {
	
	String newContactID;
	String newContactFirstName;
	String newContactLastName;
	String newContactPhoneNumber;
	String newContactAddress;
	String newContact;
	
	Vector <String> contacts = new Vector <String>(100);
	
	
	public Contact(String ID, String firstName, String lastName, String phoneNumber, String address) {
		
		if (ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid ID.");
		}
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name.");
		}
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name.");
		}
		if (phoneNumber == null || phoneNumber.length() > 10) {
			throw new IllegalArgumentException("Invalid phone number.");
		}
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address.");
		}
		
		newContactID = ID;
		newContactFirstName = firstName;
		newContactLastName = lastName;
		newContactPhoneNumber = phoneNumber;
		newContactAddress = address;
		
	}
	
	public String getID() {
		return newContactID;
	}
	
	public String getFirstName() {
		return newContactFirstName;
	}
	
	public String getLastName() {
		return newContactLastName;
	}
	
	public String getPhoneNumber() {
		return newContactPhoneNumber;
	}
	
	public String getAddress() {
		return newContactAddress;
	}

}
