package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {

	Date newDate = new Date (2021, 11, 29);
	Date invalidDate = new Date (2020, 11, 27);
	
	@Test
	void testAppointmentService() {  // checks class instantiation
		Date newDate = new Date (2021, 11, 27);
		AppointmentService testAppointmentService = new AppointmentService("1", newDate, "details for appointment");
		assertTrue(testAppointmentService.getID().equals("1"));
		assertTrue(testAppointmentService.getDate().equals(newDate));
		assertTrue(testAppointmentService.getDescription().equals("details for appointment"));
	}
	
	@Test
	void testAppointmentIDTooLong() {  // checks if the ID is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678910", newDate, "test details");
		});	
	}
	@Test
	void testAppointmentIDNull() {  // tests for null inputs
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, newDate, "test details");
		});
	}
	
	
	@Test
	void testAppointmentDateincorrect() {  // checks if the date is incorrect
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", invalidDate, "test details");
		});	
	}
	@Test
	void testAppointmentDateNull() {  // tests for null inputs
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", null, "test details");
		});
	}
	
	
	@Test
	void testAppointmentDescriptionTooLong() {  // checks if the description is too long
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", newDate, "test description totally definintely really really long like way to long way more than 50 characters theres no way it isn't at this point but i'll still keep going just to be sure that it is long enough because i would hate to have to figure out how many more characters i need to type!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		});	
	}
	@Test
	void testAppointmentDescriptionNull() {  // tests for null inputs
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", newDate, null);
		});
	}
}
