package test;

/*
 * Matt Zindler CS-320
 */

public class Task {
	
	private String taskID;  // setting up variables
	private String taskName;
	private String taskDescription;
	
	public Task (String ID, String name, String description) {  // method to add an appointment
		
		if (ID == null || ID.length() > 10) {  // checks for invalid or null inputs
			throw new IllegalArgumentException("Invalid ID.");
		}
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid date.");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description length.");
		}
		
		taskID = ID;  // sets private variables to user inputs
		taskName = name;
		taskDescription = description;	
	}
	
	public String getID() {  // getter method for ID
		return taskID;
	}
	public String getName() {  // getter method for name
		return taskName;
	}
	public String getDescription() {  // getter method for description
		return taskDescription;
	}
	
	public void setTaskID(String ID) {  // setter method for ID
		taskID = ID;
	}
	public void setTaskName(String name) {  // setter method for name
		taskName = name;
	}
	public void setTaskDescription(String description) {  // setter method for description
		taskDescription = description;
	}
}
