package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Vector;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

	@Test
	void testContactService() {  // checks class instantiation
		ContactService testContactService = new ContactService("1", "matt", "zindler", "1234567890", "123 abc street");
		assertTrue(testContactService.getIDService().equals("1"));
		assertTrue(testContactService.getFirstNameService().equals("matt"));
		assertTrue(testContactService.getLastNameService().equals("zindler"));
		assertTrue(testContactService.getPhoneNumberService().equals("1234567890"));
		assertTrue(testContactService.getAddressService().equals("123 abc street"));
	}
	
	@Test
	void checkUniqueID() {
		ContactService testContactService = new ContactService("1", "matt", "zindler", "1234567890", "123 abc street");
		assertTrue(testContactService.getIDService().equals("1"));
		assertTrue(testContactService.getFirstNameService().equals("matt"));
		assertTrue(testContactService.getLastNameService().equals("zindler"));
		assertTrue(testContactService.getPhoneNumberService().equals("1234567890"));
		assertTrue(testContactService.getAddressService().equals("123 abc street"));
		
		ContactService testContactService2 = new ContactService("2", "matt", "zindler", "1234567890", "123 abc street");
		assertTrue(testContactService2.getIDService().equals("2"));
		assertTrue(testContactService2.getFirstNameService().equals("matt"));
		assertTrue(testContactService2.getLastNameService().equals("zindler"));
		assertTrue(testContactService2.getPhoneNumberService().equals("1234567890"));
		assertTrue(testContactService2.getAddressService().equals("123 abc street"));
	}
	
	@Test
	void checkEditContact() {
		ContactService testContactService = new ContactService("1", "matt", "zindler", "1234567890", "123 abc street");
		testContactService.setFirstNameService("matt2");
		testContactService.setLastNameService("zindler2");
		testContactService.setPhoneNumberService("1234567891");
		testContactService.setAddressService("abc 123 street");
		assertTrue(testContactService.getIDService().equals("1"));
		assertTrue(testContactService.getFirstNameService().equals("matt2"));
		assertTrue(testContactService.getLastNameService().equals("zindler2"));
		assertTrue(testContactService.getPhoneNumberService().equals("1234567891"));
		assertTrue(testContactService.getAddressService().equals("abc 123 street"));
	}
}